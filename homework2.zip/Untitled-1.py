import cv2
import numpy as np
import matplotlib.pyplot as plt

# قراءة الصورة
image = cv2.imread('image7.jpg')

if image is None:
    print("❌ لم يتم العثور على الصورة")
    exit()

# تحويل من BGR إلى RGB (مهم جدا مع matplotlib)
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# تحويل إلى HSV
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# ---------- نطاقات الألوان ----------

# الأحمر
lower_red1 = np.array([0, 120, 70])
upper_red1 = np.array([10, 255, 255])
lower_red2 = np.array([170, 120, 70])
upper_red2 = np.array([180, 255, 255])

# الأخضر
lower_green = np.array([35, 50, 50])
upper_green = np.array([85, 255, 255])

# الأزرق
lower_blue = np.array([100, 150, 50])
upper_blue = np.array([140, 255, 255])

# ---------- إنشاء Masks ----------
mask_red = cv2.inRange(hsv, lower_red1, upper_red1) | \
           cv2.inRange(hsv, lower_red2, upper_red2)

mask_green = cv2.inRange(hsv, lower_green, upper_green)
mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)

combined_mask = mask_red | mask_green | mask_blue

# ---------- تحويل الصورة إلى رمادي ----------
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
gray_3ch = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)

# ---------- دمج الرمادي مع الألوان ----------
final_result = np.where(
    combined_mask[:, :, None] == 255,
    image_rgb,
    gray_3ch
)

# ---------- العرض باستخدام matplotlib ----------
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(final_result)
plt.title("Isolated Colors + Gray Background")
plt.axis("off")

plt.show()
